#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
TARGET=${1:-}
[ -n "$TARGET" ] || {
    echo "usage: $0 <Wesnoth game root or app Resources directory>" >&2
    exit 2
}

if [ -d "$TARGET/Contents/Resources" ]; then
    TARGET="$TARGET/Contents/Resources"
fi
[ -d "$TARGET" ] || {
    echo "error: target directory not found: $TARGET" >&2
    exit 1
}

mkdir -p "$TARGET/data/languages"
if [ -d "$TARGET/data/translations" ]; then
    TRANSLATIONS="$TARGET/data/translations"
else
    TRANSLATIONS="$TARGET/translations"
fi
mkdir -p "$TRANSLATIONS/ko/LC_MESSAGES"
cp "$ROOT/data/languages/ko_KR.cfg" "$TARGET/data/languages/ko_KR.cfg"
rm -f "$TRANSLATIONS/ko/LC_MESSAGES/"*.mo
cp "$ROOT/translations/ko/LC_MESSAGES/"*.mo "$TRANSLATIONS/ko/LC_MESSAGES/"
echo "installed Wesnoth Korean translation into $TARGET"
