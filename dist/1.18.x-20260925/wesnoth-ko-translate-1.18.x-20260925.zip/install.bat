@echo off
setlocal
set "ROOT=%~dp0"
set "TARGET=%~1"
if "%TARGET%"=="" (
  echo Usage: install.bat "Wesnoth game directory"
  exit /b 2
)
if not exist "%TARGET%\data\languages" mkdir "%TARGET%\data\languages"
if exist "%TARGET%\data\translations" (
  set "TRANSLATIONS=%TARGET%\data\translations"
) else (
  set "TRANSLATIONS=%TARGET%\translations"
)
if not exist "%TRANSLATIONS%\ko\LC_MESSAGES" mkdir "%TRANSLATIONS%\ko\LC_MESSAGES"
copy /Y "%ROOT%data\languages\ko_KR.cfg" "%TARGET%\data\languages\ko_KR.cfg" >NUL
del /Q "%TRANSLATIONS%\ko\LC_MESSAGES\*.mo" 2>NUL
copy /Y "%ROOT%translations\ko\LC_MESSAGES\*.mo" "%TRANSLATIONS%\ko\LC_MESSAGES\" >NUL
echo Installed Wesnoth Korean translation into %TARGET%
endlocal
